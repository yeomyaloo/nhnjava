package com.nhnacademy.jdbc.board.user.exception;

public class UserNotMatchesException extends RuntimeException {
}
