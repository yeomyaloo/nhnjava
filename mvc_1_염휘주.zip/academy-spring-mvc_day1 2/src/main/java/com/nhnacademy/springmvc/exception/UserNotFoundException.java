package com.nhnacademy.springmvc.exception;

public class UserNotFoundException extends RuntimeException {
}
