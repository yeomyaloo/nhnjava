package com.nhnacademy.springmvc.controller;

// marker interface
public interface ControllerBase {
}
