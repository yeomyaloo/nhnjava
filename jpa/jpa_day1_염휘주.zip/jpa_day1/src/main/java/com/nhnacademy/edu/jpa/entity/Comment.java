package com.nhnacademy.edu.jpa.entity;


import javax.persistence.*;
import javax.xml.crypto.Data;
import java.util.Date;

@Table(name = "Comment")
@Entity
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private String commentId;
    @Column(name = "parent_comment_id")
    private Long parentCommentId;
    private String content;
    @Column(name = "created_at")
    private Date createdAt;
    private String username;
    private String commentWriter;


}
