package com.nhnacademy.edu.jpa.entity;


import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "Board")
public class Board {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "boardId")
    private Long boardId;
    private String title;
    private String content;
    private int visitCnt;
    private String writeName;
    private Long writeId;

    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Date createdAt;
    private String modifyName;



}
