package com.nhnacademy.edu.jpa.controller;

public interface ControllerBase {
}
