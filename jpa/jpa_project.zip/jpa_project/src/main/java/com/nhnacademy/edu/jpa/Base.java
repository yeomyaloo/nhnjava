package com.nhnacademy.edu.jpa;

public interface Base {
}
