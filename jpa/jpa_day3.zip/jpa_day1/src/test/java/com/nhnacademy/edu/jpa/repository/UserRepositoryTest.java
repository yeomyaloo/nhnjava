package com.nhnacademy.edu.jpa.repository;

import com.nhnacademy.edu.jpa.config.RootConfig;
import com.nhnacademy.edu.jpa.config.WebConfig;
import com.nhnacademy.edu.jpa.entity.User;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.ContextHierarchy;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


@ExtendWith(SpringExtension.class)
@WebAppConfiguration
@Transactional
@ContextHierarchy({
        @ContextConfiguration(classes = RootConfig.class),
        @ContextConfiguration(classes = WebConfig.class)
})
class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;

    @Test
    public void insert(){

        User user = new User("test", "1234");
        userRepository.save(user);


        assertTrue(userRepository.existsById(3L));

    }



    @Test
    public void update(){

        User user = userRepository.getByUserId(2L);
        user.setPassword("bbbb");
        userRepository.saveAndFlush(user);

        String userPassword = userRepository.getByUserId(2L).getPassword();
        assertEquals(userPassword, "bbbb");


    }



    @Test
    public void getUserTest(){

        List<User> users = userRepository.getAllBy();
        assertEquals(users.get(0).getUsername(), "admin");
        assertEquals(users.get(1).getUsername(), "user");

    }



}