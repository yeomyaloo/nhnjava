package com.nhnacademy.edu.jpa.service;

import com.nhnacademy.edu.jpa.entity.User;
import com.nhnacademy.edu.jpa.repository.UserRepository;

public interface UserService {

    User getUser(Long id);

    User createUser(String username, String password);

    User modifyUser(User user);


}
