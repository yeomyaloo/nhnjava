package com.nhnacademy.edu.jpa.repository;

import com.mysql.cj.log.Log;
import com.nhnacademy.edu.jpa.entity.Comment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CommentRepository extends JpaRepository<Comment,Long> {


    public List<Comment> getAllBy();

    public Comment getCommentByCommentId(Long id);

}
