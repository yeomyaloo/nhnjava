package com.nhnacademy.edu.jpa.service;

import com.nhnacademy.edu.jpa.entity.User;
import com.nhnacademy.edu.jpa.repository.UserRepository;

import java.util.Objects;

public class UserServiceImpl implements UserService{

    private final UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }


    @Override
    public User getUser(Long id) {
        User user = userRepository.getByUserId(id);
        if(Objects.nonNull(user)){
            return user;
        }
        throw new UserNotFoundException();
    }

    @Override
    public User createUser(String username, String password) {

        return null;
    }

    @Override
    public User modifyUser(User user) {
        return null;
    }
}
