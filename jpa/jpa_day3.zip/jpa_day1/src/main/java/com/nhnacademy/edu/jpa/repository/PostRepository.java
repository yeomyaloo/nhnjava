package com.nhnacademy.edu.jpa.repository;

import com.nhnacademy.edu.jpa.entity.Post;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PostRepository extends JpaRepository<Post, Long> {

    public Post getPostsByPostId(Long id);

    public List<Post> getAllBy();

    public void deleteByPostId(Long id);

    public boolean existsByPostId(Long id);
}
