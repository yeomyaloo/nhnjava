//package com.nhnacademy.edu.jpa.entity;
//
//
//import lombok.*;
//
//import javax.persistence.*;
//import java.io.Serializable;
//
////해당 과제 DB table엔 아직 좋아요 관련 테이블이 없습니다.
//@Table(name = "Like")
//@Entity
//
//public class Like {
//
//    @Id
//    @Column(name = "likeId")
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long likeId;
//
//    @Id
//    @Column(name = "userId")
//    private Long userId;
//
//
//    private boolean isLike;
//
//    @NoArgsConstructor
//    @AllArgsConstructor
//    @EqualsAndHashCode
//    @Getter
//    @Setter
//    @Embeddable
//    public static class Pk implements Serializable {
//        private Long likeId;
//        private Long userId;
//    }
//
//
//
//}
