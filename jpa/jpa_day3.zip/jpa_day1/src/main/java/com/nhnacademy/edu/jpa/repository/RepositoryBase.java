package com.nhnacademy.edu.jpa.repository;

public interface RepositoryBase {
}
