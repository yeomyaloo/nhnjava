package com.nhnacademy.edu.jpa.repository;

import com.nhnacademy.edu.jpa.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface UserRepository extends JpaRepository<User, Long> {

    public List<User> getAllBy();

    public User getByUserId(Long id);

    public User getUserByUsernameAndPassword(String username, String password);


}
