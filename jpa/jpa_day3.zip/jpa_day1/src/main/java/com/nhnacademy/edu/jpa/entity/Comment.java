package com.nhnacademy.edu.jpa.entity;


import lombok.Getter;

import javax.persistence.*;
import javax.xml.crypto.Data;
import java.util.Date;

@Table(name = "Comment")
@Entity
@Getter
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "comment_id")
    private Long commentId;

    @Column(name = "parent_comment_id")
    private Long parentCommentId;

    private String content;

    @Basic(optional = false)
    @Column(name = "created_at", insertable = false, unique = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @JoinColumn(name = "user_id")
    @ManyToOne
    private User user;

    @JoinColumn(name = "post_id")
    @ManyToOne
    private Post post;


}
