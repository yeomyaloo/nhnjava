package com.nhnacademy.edu.jpa.controller;


import com.nhnacademy.edu.jpa.entity.User;
import com.nhnacademy.edu.jpa.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users/{userId}")
public class UserRestController {

    private final UserRepository userRepository;

    public UserRestController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @ModelAttribute(value = "user",binding = false)
    public User getuser(@PathVariable("userId") Long userId){
        getuser(userId)

    }
}
