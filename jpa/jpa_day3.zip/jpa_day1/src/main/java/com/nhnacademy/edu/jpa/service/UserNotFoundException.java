package com.nhnacademy.edu.jpa.service;

public class UserNotFoundException extends RuntimeException {
    public UserNotFoundException() {
        super("not found user error!");
    }
}
