package com.nhnacademy.edu.jpa.entity;


import lombok.Getter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "Post")
@Getter
public class Post {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "post_id")
    private Long postId;

    private String title;

    private String content;

    @Basic(optional = false)
    @Column(name = "created_at", insertable = false, unique = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    //User 객체를 가져와서 .. name, id를 넘겨받자 ~!
    @JoinColumn(name = "user_id")
    @ManyToOne
    private User user;





}
