package com.nhnacademy.springmvc;


//marking용 인터페이스 아무것도 안함 root Configㅇ에 기준이 되는 인터페이스
public interface Base {
}
