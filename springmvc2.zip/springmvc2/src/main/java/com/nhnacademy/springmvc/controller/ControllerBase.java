package com.nhnacademy.springmvc.controller;


//marking interface
public interface ControllerBase {
}
