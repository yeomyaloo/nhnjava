package com.nhnacademy;

public enum Action {
    DEPOSIT, WITHDRAW
}
