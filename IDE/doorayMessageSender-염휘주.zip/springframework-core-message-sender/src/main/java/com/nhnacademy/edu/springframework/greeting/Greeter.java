package com.nhnacademy.edu.springframework.greeting;

public interface Greeter {
    boolean sayHello();
}
