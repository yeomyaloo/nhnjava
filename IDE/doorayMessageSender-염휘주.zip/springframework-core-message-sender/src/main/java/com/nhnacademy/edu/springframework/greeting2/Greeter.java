package com.nhnacademy.edu.springframework.greeting2;

public interface Greeter {

    boolean sayHello();

}
