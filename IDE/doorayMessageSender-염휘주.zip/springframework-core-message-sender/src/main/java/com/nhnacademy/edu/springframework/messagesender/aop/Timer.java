package com.nhnacademy.edu.springframework.messagesender.aop;


@Timer
public @interface Timer {

}
