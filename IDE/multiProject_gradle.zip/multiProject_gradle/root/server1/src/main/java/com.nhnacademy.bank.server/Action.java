package com.nhnacademy.bank.server;

public enum Action {
    DEPOSIT, WITHDRAW
}
