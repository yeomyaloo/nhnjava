package com.nhnacademy.edu.springframework.project.service;

import java.io.IOException;

public interface DataLoadService {
    void loadAndMerge() throws IOException;
}
