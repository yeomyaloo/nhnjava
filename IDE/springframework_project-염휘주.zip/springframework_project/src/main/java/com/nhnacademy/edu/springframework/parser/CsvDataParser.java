package com.nhnacademy.edu.springframework.parser;

import java.io.File;
import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;


@Component
public class CsvDataParser implements DataParser{

    @Override
    public void JSONload() throws IOException {
     /*   URL path = this.getClass().getResource("Tariff_20220331.json");

        File jsonFile = new File(path.getFile());
*/
        File file = new File("C:\\Users\\yeomyalooo\\Documents\\GitHub\\java\\springframework_project\\src\\main\\java\\com\\nhnacademy\\edu\\springframework\\parser\\Tariff_20220331.json");
        ObjectMapper mapper = new ObjectMapper();

        List<String> list = mapper.readValue(file, ArrayList.class);

        System.out.println(list);
    }

/*    public static void main(String[] args) throws IOException {
        DataParser parser = new CsvDataParser();
        parser.JSONload();

    }*/
}
