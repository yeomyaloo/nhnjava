package com.nhnacademy.edu.springframework.parser;

import java.io.IOException;

public interface


DataParser {

    public void JSONload() throws IOException;

}
