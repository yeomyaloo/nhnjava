package com.nhnacademy.edu.springframework.service;


import org.springframework.stereotype.Component;

@Component
public class BasicWaterBillService implements WaterBillService {

    @Override
    public void payment(int water) {

    }


}
