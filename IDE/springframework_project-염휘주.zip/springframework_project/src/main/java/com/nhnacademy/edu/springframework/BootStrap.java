package com.nhnacademy.edu.springframework;

public class BootStrap {

    public static void main(String[] args) {

    }
}
