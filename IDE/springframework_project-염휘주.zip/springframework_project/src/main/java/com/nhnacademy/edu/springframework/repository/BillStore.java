package com.nhnacademy.edu.springframework.repository;

public interface BillStore {


    public void load();

    public void usage(int waterUsage);
}
