package com.nhnacademy.edu.springframework.repository;

import com.nhnacademy.edu.springframework.parser.CsvDataParser;
import com.nhnacademy.edu.springframework.parser.DataParser;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

@Component
public class BasicBillStore implements BillStore{


    private static BasicBillStore instance = new BasicBillStore();

    private BasicBillStore() {
    }

    public static BillStore getInstance(){
        if (instance == null){
            return new BasicBillStore();
        }

        return instance;
    }

    List<String> list;
    @Override
    public void load() {

        List<List<String>> list = new ArrayList<List<String>>();
        BufferedReader br = null;

        try {
            br = Files.newBufferedReader(Paths.get("C:\\Users\\yeomyalooo\\Documents\\GitHub\\java\\springframework_project\\src\\main\\resources\\data\\Tariff_20220331.csv"));
            String line = "";

            while ((line = br.readLine()) != null){
                List<String> tmp = new ArrayList<String >();

                String array[] =line.split(",");
                tmp = Arrays.asList(array);


                list.add(tmp);

            }
        } catch (IOException e) {
                e.printStackTrace();
        }finally {
            try {
                if(br != null){
                    br.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        System.out.println(list);


    }
    @Override
    public void usage(int waterUsage) {
        instance.load();


    }

    public static void main(String[] args) throws IOException {
        BillStore billStore = new BasicBillStore();

        billStore.load();

        DataParser parser = new CsvDataParser();
        parser.JSONload();
    }
}
