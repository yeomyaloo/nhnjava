package com.nhnacademy.edu.springframework.config;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@ComponentScan(basePackages = "com.nhnacademy.edu.springframework")
@Configuration
public class Config {

}
