package com.nhnacademy.edu.springframework.service;

public interface WaterBillService {

    public void payment(int water);
}


