package com.nhnacademy.edu.springframework.parser;

import static org.junit.jupiter.api.Assertions.*;

class CsvDataParserTest {

}