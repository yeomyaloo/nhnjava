package com.nhnacademy.edu.springframework.repository;

import static org.junit.jupiter.api.Assertions.*;

class BasicBillStoreTest {

}