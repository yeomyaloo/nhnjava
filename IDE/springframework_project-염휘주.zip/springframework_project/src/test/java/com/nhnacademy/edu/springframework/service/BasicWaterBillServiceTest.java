package com.nhnacademy.edu.springframework.service;

import static org.junit.jupiter.api.Assertions.*;

class BasicWaterBillServiceTest {

}