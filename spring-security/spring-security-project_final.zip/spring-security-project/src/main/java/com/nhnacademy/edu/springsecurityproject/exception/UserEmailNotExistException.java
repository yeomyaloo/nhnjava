package com.nhnacademy.edu.springsecurityproject.exception;

public class UserEmailNotExistException extends RuntimeException {
}
