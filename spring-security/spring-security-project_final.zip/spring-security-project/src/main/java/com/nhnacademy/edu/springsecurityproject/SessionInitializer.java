package com.nhnacademy.edu.springsecurityproject;

import org.springframework.session.web.context.AbstractHttpSessionApplicationInitializer;

// TODO #5: DelegatingFilterProxy + `springSessionRepositoryFilter`
public class SessionInitializer extends AbstractHttpSessionApplicationInitializer {
}
