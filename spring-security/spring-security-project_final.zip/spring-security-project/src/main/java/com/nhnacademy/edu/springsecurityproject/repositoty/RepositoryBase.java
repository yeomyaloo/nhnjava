package com.nhnacademy.edu.springsecurityproject.repositoty;

public interface RepositoryBase {
}
