package com.nhnacademy.edu.restapi_final_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiFinalProjectApplicationTests {

    @Test
    void contextLoads() {


    }

}
