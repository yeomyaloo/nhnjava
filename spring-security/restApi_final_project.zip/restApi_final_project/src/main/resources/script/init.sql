/**TRUNCATE department;**/





LOAD DATA local infile '/Users/yeomhwiju/department.txt' into table employee fields terminated by '/t'(employee_id,employee_name);


