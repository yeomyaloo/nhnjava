package com.nhnacademy.edu.springboot.student.adaptor.in;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Result {
    private String result;
    private String message;
}
