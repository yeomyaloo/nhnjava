package com.nhnacademy.edu.springboot.student.adaptor.in;


import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class StudentControllerAdvice {

    @ExceptionHandler(RuntimeException.class)
    @ResponseBody
    public Result handleRuntimeException (RuntimeException ex) {
        return new Result("ERROR", ex.getMessage());
    }
}
