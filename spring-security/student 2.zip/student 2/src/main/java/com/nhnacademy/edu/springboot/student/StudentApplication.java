package com.nhnacademy.edu.springboot.student;

import com.nhnacademy.edu.springboot.student.config.SystemAuthorProperties;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.metrics.buffering.BufferingApplicationStartup;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@SpringBootApplication
@ConfigurationPropertiesScan
public class StudentApplication {

	public static void main(String[] args) {
		SpringApplication springApplication = new SpringApplication(StudentApplication.class);
		springApplication.setApplicationStartup(new BufferingApplicationStartup(2048));
		springApplication.run(args);
	}

}
