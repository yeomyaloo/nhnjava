package com.nhnacademy.edu.springsecurityproject;

// marker interface
public interface Base {
}
