package com.nhnacademy.edu.springsecurityproject.controller;

public interface ControllerBase {
}
