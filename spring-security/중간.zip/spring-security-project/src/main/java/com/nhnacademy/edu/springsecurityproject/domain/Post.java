package com.nhnacademy.edu.springsecurityproject.domain;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class Post {
        private String email;
}
