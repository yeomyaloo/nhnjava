package com.nhnacademy.edu.open_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
