package com.nhnacademy.edu.open_api.controller;


import com.nhnacademy.edu.open_api.domain.CreateAccount;
import com.nhnacademy.edu.open_api.domain.RequestAccount;
import lombok.RequiredArgsConstructor;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;

@RestController
@RequestMapping("/accounts")
@RequiredArgsConstructor
public class OpenApiRestController {

    private final RestTemplate restTemplate;



    @GetMapping
    public List<RequestAccount> getAccountList(){

        UriComponents uriComponents = UriComponentsBuilder
                .newInstance()
                .scheme("http")
                .host("localhost")
                .port(9090)
                .path("/accounts")
                .build();


        ResponseEntity<List<RequestAccount>> response = restTemplate.exchange(uriComponents.toUri(),HttpMethod.GET, null, new ParameterizedTypeReference<List<RequestAccount>>() {});
        List<RequestAccount> list = response.getBody();
        return list;
    }

    @GetMapping("/{id}")
    public RequestAccount getAccount(@PathVariable("id") String id){

        UriComponents uriComponents = UriComponentsBuilder
                .newInstance()
                .scheme("http")
                .host("localhost")
                .port(9090)
                .path("accounts/")
                .path(id)
                .build();


        return restTemplate.getForObject(uriComponents.toUri(), RequestAccount.class);
    }



    @PostMapping
    public RequestAccount createdAccount(@RequestBody CreateAccount createAccount){
        UriComponents uriComponents = UriComponentsBuilder
                .newInstance()
                .scheme("http")
                .host("localhost")
                .port(9090)
                .path("accounts")
                .build();

        return restTemplate.postForObject(uriComponents.toUri(), createAccount, RequestAccount.class);

    }


    @DeleteMapping("/{id}")
    public RequestAccount deleteAccount(@PathVariable("id") String id){
        UriComponents uriComponents = UriComponentsBuilder
                .newInstance()
                .scheme("http")
                .host("localhost")
                .port(9090)
                .path("accounts/")
                .path(id)
                .build();



        RequestAccount requestAccount = restTemplate.getForObject(uriComponents.toUri(), RequestAccount.class);

        restTemplate.delete(uriComponents.toUri());

        return requestAccount;


    }





}
