package com.nhnacademy.edu.open_api.domain;

import lombok.Getter;

@Getter
public class CreateAccount {
    String number;
    Integer balance;
}
