package com.nhnacademy.exception;

public class InvalidLaguageException extends RuntimeException {

    public InvalidLaguageException(String message) {
        super();
    }
}
