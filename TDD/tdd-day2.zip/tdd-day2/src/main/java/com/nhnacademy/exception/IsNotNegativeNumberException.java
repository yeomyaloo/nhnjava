package com.nhnacademy.exception;

public class IsNotNegativeNumberException extends RuntimeException {
    public IsNotNegativeNumberException() {
        super("negative number");
    }
}
