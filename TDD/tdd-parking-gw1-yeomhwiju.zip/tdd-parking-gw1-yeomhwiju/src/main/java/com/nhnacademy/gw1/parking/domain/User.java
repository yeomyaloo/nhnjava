package com.nhnacademy.gw1.parking.domain;

public interface User {

    public String getId();
    public int getMoney();
    public String getCarNumber();

}
