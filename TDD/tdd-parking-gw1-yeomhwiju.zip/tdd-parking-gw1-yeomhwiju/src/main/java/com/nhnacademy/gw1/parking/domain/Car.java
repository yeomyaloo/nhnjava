package com.nhnacademy.gw1.parking.domain;

public class Car {

    private final String number;

    public Car(String number) {
        this.number = number;
    }

    public String getCarNumber() {
        return number;
    }
}
