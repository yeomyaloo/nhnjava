package com.nhnacademy.gw1.parking.domain;

import com.nhnacademy.gw1.parking.domain.Car;

public class Entrance {
    public Car scan(Car entranceCar) {
        return entranceCar;
    }

}
