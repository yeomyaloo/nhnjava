package com.nhnacademy.gw1.parking.exception;

public class NoSuchExitCarUserException extends RuntimeException {
    public NoSuchExitCarUserException() {
        super();
    }
}
