package regular;

import javax.lang.model.element.ElementVisitor;
import java.beans.Expression;
import java.util.BitSet;

public class Literals implements Visitor {
    private final char literals;

    public Literals(char literals) {
        this.literals = literals;

    }


    public BitSet then(Literal a) {
    }

    public Object start() {
    }

    public Expression or(BitSet then) {
    }
}
