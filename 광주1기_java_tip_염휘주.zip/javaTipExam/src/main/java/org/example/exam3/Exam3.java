package org.example.exam3;

import java.util.Scanner;

public class Exam3 {
    static String[] arr = new String[3];
    static boolean[] visited = new boolean[3];

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        powerSet(0);
    }

    private static void powerSet(int cnt) {
        if (cnt == arr.length) {
            for( int i = 0; i < arr.length; i++){
                //선택된 숫자만 출력
                if(visited[i]){
                    System.out.print("["+arr[i] +" ");
                }
            }
            System.out.println();
        }

    }

}
