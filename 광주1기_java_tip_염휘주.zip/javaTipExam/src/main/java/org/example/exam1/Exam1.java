package org.example.exam1;

import java.util.LinkedList;

public class Exam1<V extends Comparable <V>> {
    class Node{
        Integer data;
        Node next;


        public Node (Integer data){
            this.data = data;
            this.next = null;
        }

        public Node(){
            this.data = null;
            this.next = null;
        }

        public Integer getData() {
            return data;
        }

        public Node getNext() {
            return next;
        }

        public void setNext(Node next) {
            this.next = next;
        }
    } //Node 끝
    //Linked List 시작

    LinkedList<V> list;


    private Node head;
    private int size;

    public Exam1() {
        this.head = null;
        this.size = 0;
    }

    public boolean isEmpty(){
        return head == null;
    }

    public V push(V value) {
        if (isEmpty()){
            head.data = (Integer) value;
            head.next = null;
        }
        while (head.next != null){
            if(head.data > (Integer) value){
                head.next = head;//현재 head보다 앞에 들어오는 경우라면 head를 next로 만들고 새로운 Node를 삽입해준다.
                head = new Node((Integer) value);

            }
        }
        return (V) head;
    }

    public V pop(){

        Integer data = head.data;
        while (head.next != null){
            data = head.data;
        }
        return (V) data;
    }




    public static void main(String[] args) {

        Exam1<Integer> queue = new Exam1<>();
        queue.push(5);
        queue.push(2);
        queue.push(7);

        System.out.println(queue.pop());
        System.out.println(queue.pop());
        System.out.println(queue.pop());


    }

}
