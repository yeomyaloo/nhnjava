package org.example.exam4;

import java.util.List;
import java.util.Scanner;

public class Exam4 {

    public static void main(String[] args) {

        Scanner sc= new Scanner(System.in);
        int n = sc.nextInt();

        String[][] people = new String[n][3];
        boolean[] visited = new boolean[n];


    }
    /**DFS(재귀로 구현)으로 구현 가능
     * DFS(친구관계, 시작지점)을 전부 반복문으로 돌아서 해당 cnt(몇번 만에 연예인을 찾는지)를 알아내고
     * 해당 for문(시작지점)이 끝나면 다음 지점으로 가기 전 minimum 값을 비교해 젤 작은 값으로 교환할 수 있게 한다.
     * 이때 DFS의 종료 조건은 DFS를 모두 돌았을 때 종료한다. (모두 다 살펴보아야 함.)
     * */

    public int DFS(int L, String[][] people, String ){
        if

        return cnt;
    }


}
