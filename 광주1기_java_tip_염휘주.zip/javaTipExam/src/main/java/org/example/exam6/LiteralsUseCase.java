package org.example.exam6;

import regular.Literal;
import regular;

import java.beans.Expression;

public class LiteralsUseCase {
    public static void main(String[] args) {
        Literals a = new Literals('a');
        Literals b = new Literals('b');

        Expression a_ab = a.or(a.then(b));
        Expression ba_a0n = b.then(a).or(Expression.epsilon.or(a.start()));

        System.out.println(a_ab);
        System.out.println(Literals.of(a_ab));
        System.out.println(ba_a0n);
        System.out.println(Literals.of(ba_a0n));


    }

}
