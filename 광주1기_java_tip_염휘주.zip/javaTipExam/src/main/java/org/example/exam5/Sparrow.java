package org.example.exam5;

public class Sparrow extends Bird implements Flyable{
    @Override
    public boolean isFlyable(Animal animal) {
        return (animal instanceof Flyable);
    }

    @Override
    public boolean isSwimable(Animal animal) {
        return (animal instanceof Swimable);
    }
}
