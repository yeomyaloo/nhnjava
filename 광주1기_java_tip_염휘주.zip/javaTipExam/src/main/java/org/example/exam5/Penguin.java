package org.example.exam5;

public class Penguin extends Bird implements Swimable{
    @Override
    public boolean isFlyable(Animal animal) {
        return false;
    }

    @Override
    public boolean isSwimable(Animal animal) {
        return true;
    }
}
