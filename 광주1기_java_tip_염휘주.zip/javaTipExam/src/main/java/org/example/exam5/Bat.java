package org.example.exam5;

public class Bat extends Mammalia implements Flyable, Swimable{

    @Override
    public boolean isFlyable(Animal animal) {
        return true;
    }

    @Override
    public boolean isSwimable(Animal animal) {
        return true;
    }
}
