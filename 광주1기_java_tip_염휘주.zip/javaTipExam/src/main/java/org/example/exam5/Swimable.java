package org.example.exam5;

public interface Swimable {
}
