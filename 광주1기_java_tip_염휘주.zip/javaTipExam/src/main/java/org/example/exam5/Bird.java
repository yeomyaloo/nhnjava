package org.example.exam5;

public abstract class Bird implements Animal{

}
