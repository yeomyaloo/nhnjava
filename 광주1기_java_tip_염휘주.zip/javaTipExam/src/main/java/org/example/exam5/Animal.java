package org.example.exam5;

public interface Animal {
    boolean isFlyable(Animal animal);
    boolean isSwimable(Animal animal);

}
