package org.example.exam5;

public abstract class Mammalia implements Animal {
}
