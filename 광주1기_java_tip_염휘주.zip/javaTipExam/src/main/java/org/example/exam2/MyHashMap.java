package org.example.exam2;

public class MyHashMap<V> {
    class Node{

        String key;
        V value;
        Node next; //key가 동일한 것을 참조해야 한다.

        public Node() {
            this.key = null;
            this.value = null;
            this.next = null;
        }

        public Node(String key, V value) {
            this.key = key;
            this.value = value;
            this.next = null;
        }
    }


    private Integer hashCode;
    private Node head;

    public MyHashMap() {
        this.head = null;
        this.hashCode = null;
    }

    public boolean isEmpty(){
        return head == null;
    }

    public void put(String key, V value){
        if(hashCode == null){
            this.hashCode = 0;
        }





    }

    public static void main(String[] args) {
        MyHashMap<String> hashMap = new MyHashMap<>();

        hashMap.put("key", "value1");
        hashMap.put("key2", "value2");
        hashMap.put("ke2y", "value3");
    }
}


