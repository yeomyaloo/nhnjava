package org.example.exam7;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;

public class Exam7 {
    static class Chief implements Runnable{
        String menu;
        Map<String, Integer> cook;
        long interval;
        Lock lock;

        public Chief(String menu, long interval) {
            this.cook = new HashMap<>();
            this.menu = menu;
            this.interval = interval;
        }

        public Chief(String menu) {
            this.cook = new HashMap<>();
            this.menu = menu;
            this.interval = 10000;
        }



        @Override
        public void run() {
            try{
                while (true){
                    Integer stock = this.cook.get(menu);
                    if (this.cook.containsKey(menu) && this.cook.get(menu)+1 < 3){
                        notify();
                        stock = this.cook.get(menu) + 1;
                        cook.put(menu,stock);
                        System.out.println("요리를 완성했습니다.");

                    } else if (!(this.cook.containsKey(menu)) || this.cook.get(menu)==0){
                        notify();
                        stock = 1;
                        cook.put(menu,stock);
                        System.out.println("요리를 완성했습니다.");
                    } else{
                        wait();
                    }
                    Thread.sleep(this.interval);
                }

            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    static class Customer implements Runnable{
        Chief cook;

        public Customer(Chief chief) {
            this.cook = chief;
        }

        @Override
        public void run() {
            try{
                while (true) {
                    this.cook.get()
                }
            }
        }
    }
}
