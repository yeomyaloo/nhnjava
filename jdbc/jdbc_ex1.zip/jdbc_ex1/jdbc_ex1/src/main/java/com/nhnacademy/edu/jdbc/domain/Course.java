package com.nhnacademy.edu.jdbc.domain;

public class Course {
}
