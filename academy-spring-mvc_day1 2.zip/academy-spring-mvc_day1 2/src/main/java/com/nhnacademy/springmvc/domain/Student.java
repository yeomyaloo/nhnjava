package com.nhnacademy.springmvc.domain;

public class Student {
    private long id;
    private String name;
    private String email;
    private int score;
    private String comment;

}
